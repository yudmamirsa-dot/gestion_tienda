EVIDENCIA GA8 - Integración de Módulos

Esta carpeta contiene:
1. Evidencia_GA8_Integracion.docx - Documento de la evidencia.
2. gestion_tienda.sql - Script SQL de la base de datos.
3. INSTRUCCIONES.txt - Pasos para ejecutar el proyecto.
4. Capturas del sistema en la carpeta 'capturas'.

Autora:
Yudi Marcela Mira Salazar
Repositorio: https://github.com/yudmamirsa-dot/gestion_tienda.git
